import React from 'react';

// --- Web Icons (Keep existing for Admin Panel) ---

export const WALogo = () => (
  <div className="flex items-center gap-2">
    <svg viewBox="0 0 33 33" width="33" height="33" className="" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.6 0C7.4 0 0 7.4 0 16.5C0 19.5 0.8 22.3 2.2 24.8L0.6 30.6C0.5 31.1 0.9 31.5 1.4 31.4L7.3 29.8C9.7 31.2 12.6 32 15.6 32H15.7C24.9 31.9 32.3 24.5 32.3 15.4C32.3 6.3 24.8 0 16.6 0ZM16.6 29.2C13.9 29.2 11.3 28.5 9.1 27.2L8.5 26.8L3.3 28.2L4.7 23.1L4.3 22.5C2.9 20.1 2.2 17.4 2.2 15.4C2.3 7.5 8.7 1.1 16.6 1.1C24.5 1.1 30.1 7.5 30.1 15.4C30.1 23.3 23.7 29.2 16.6 29.2Z" fill="#25D366"/>
      <path d="M25.3 20.8C24.9 20.6 22.8 19.6 22.4 19.5C22 19.4 21.7 19.3 21.4 19.8C21.1 20.3 20.2 21.3 20 21.6C19.7 21.9 19.4 21.9 19 21.7C18.6 21.5 17.3 21.1 15.8 19.7C14.6 18.7 13.8 17.4 13.5 16.9C13.2 16.4 13.5 16.1 13.7 15.9C13.9 15.7 14.2 15.4 14.4 15.1C14.6 14.8 14.7 14.6 14.9 14.3C15 14 14.9 13.7 14.8 13.5C14.7 13.3 13.8 11.2 13.5 10.3C13.1 9.4 12.7 9.5 12.4 9.5C12.2 9.5 11.9 9.5 11.6 9.5C11.3 9.5 10.9 9.6 10.5 10C10.1 10.4 9 11.5 9 13.7C9 15.9 10.6 18 10.8 18.3C11 18.6 13.9 23.1 18.4 25C19.5 25.5 20.3 25.8 21 26C22 26.3 22.9 26.3 23.6 26.2C24.4 26.1 26 25.2 26.4 24.2C26.7 23.2 26.7 22.3 26.6 22.1C26.5 22 26.2 21.9 25.8 21.7L25.3 20.8Z" fill="#25D366"/>
      <path d="M16.6 29.2C13.9 29.2 11.3 28.5 9.1 27.2L8.5 26.8L3.3 28.2L4.7 23.1L4.3 22.5C2.9 20.1 2.2 17.4 2.2 15.4C2.3 7.5 8.7 1.1 16.6 1.1C24.5 1.1 30.1 7.5 30.1 15.4C30.1 23.3 23.7 29.2 16.6 29.2Z" fill="white"/>
      <path d="M25.3 20.8C24.9 20.6 22.8 19.6 22.4 19.5C22 19.4 21.7 19.3 21.4 19.8C21.1 20.3 20.2 21.3 20 21.6C19.7 21.9 19.4 21.9 19 21.7C18.6 21.5 17.3 21.1 15.8 19.7C14.6 18.7 13.8 17.4 13.5 16.9C13.2 16.4 13.5 16.1 13.7 15.9C13.9 15.7 14.2 15.4 14.4 15.1C14.6 14.8 14.7 14.6 14.9 14.3C15 14 14.9 13.7 14.8 13.5C14.7 13.3 13.8 11.2 13.5 10.3C13.1 9.4 12.7 9.5 12.4 9.5C12.2 9.5 11.9 9.5 11.6 9.5C11.3 9.5 10.9 9.6 10.5 10C10.1 10.4 9 11.5 9 13.7C9 15.9 10.6 18 10.8 18.3C11 18.6 13.9 23.1 18.4 25C19.5 25.5 20.3 25.8 21 26C22 26.3 22.9 26.3 23.6 26.2C24.4 26.1 26 25.2 26.4 24.2C26.7 23.2 26.7 22.3 26.6 22.1C26.5 22 26.2 21.9 25.8 21.7L25.3 20.8Z" fill="#25D366"/>
    </svg>
    <span className="text-[#25D366] font-bold text-[19px] tracking-tight">WhatsApp</span>
  </div>
);

export const MenuIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#54656f]">
    <line x1="3" y1="12" x2="21" y2="12"></line>
    <line x1="3" y1="6" x2="21" y2="6"></line>
    <line x1="3" y1="18" x2="21" y2="18"></line>
  </svg>
);

export const DownloadIcon = () => (
  <div className="w-9 h-9 border border-[#25D366] rounded-full flex items-center justify-center">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#25D366" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
  </div>
);

export const DownloadIconWhite = () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="7 10 12 15 17 10"></polyline>
      <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
);

// --- Mobile Android Icons ---

export const SearchIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="">
    <path fill="currentColor" d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"></path>
  </svg>
);

export const FilterIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="">
    <path fill="currentColor" d="M10 18.1h4v-2h-4v2zm-7-12v2h18v-2H3zm3 7h12v-2H6v2z"></path>
  </svg>
);

export const ChatIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="">
    <path fill="currentColor" d="M19.005 3.175H4.674C3.642 3.175 3 3.789 3 4.821v11.029c0 1.032.642 1.646 1.674 1.646h1.528l-1.42 2.796c-.224.537.065.917.494.917h14.748c1.032 0 1.674-.614 1.674-1.646V4.821c0-1.032-.642-1.646-1.674-1.646zM5.233 4.675h13.169c.563 0 .563.486.563.563v10.196c0 .563-.486.563-.563.563H5.233c-.077 0-.563 0-.563-.563V5.238c0-.077 0-.563.563-.563z"></path>
  </svg>
);

export const MoreIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="">
    <path fill="currentColor" d="M12 7a2 2 0 1 0-.001-4.001A2 2 0 0 0 12 7zm0 2a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 9zm0 6a2 2 0 1 0-.001 3.999A2 2 0 0 0 12 15z"></path>
  </svg>
);

export const PlusIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="">
    <path fill="currentColor" d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"></path>
  </svg>
);

export const SecurityIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
  </svg>
);

export const CameraIcon = () => (
    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
        <path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z" />
        <path d="M9 5L7 8H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2h-3l-2-3H9Z" fillRule="evenodd" clipRule="evenodd" fill="none" stroke="currentColor" strokeWidth="2"/>
    </svg>
);

export const MetaCircleIcon = () => (
    <div className="w-5 h-5 rounded-full border-2 border-blue-400 opacity-80 flex items-center justify-center">
        <div className="w-4 h-4 rounded-full border border-purple-500 opacity-60"></div>
    </div>
);

export const CommunityIcon = () => (
    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
        <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
    </svg>
);

export const StatusIcon = () => (
    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
    </svg>
);

export const CallsIcon = () => (
    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
        <path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56-.35-.12-.74-.03-1.01.24l-1.57 1.97c-2.83-1.44-5.15-3.75-6.59-6.59l1.97-1.57c.27-.27.35-.66.24-1.01-.36-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3.28 3 3.93 3 4.74 3 14.05 10.95 22 20.26 22c.81 0 1.46-.65 1.46-1.19v-3.8c0-.54-.45-.99-.99-.99z"/>
    </svg>
);

export const FABIcon = () => (
    <svg viewBox="0 0 24 24" width="24" height="24" fill="white">
        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
        <path d="M11 9h2v2h2v2h-2v2h-2v-2H9v-2h2z" />
    </svg>
);